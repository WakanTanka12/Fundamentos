#include <iostream>
#include "funciones.h"  // Incluir el archivo de cabecera

using namespace std;

// Definici�n de la funci�n saludar
void saludar() {
    cout << "�Hola desde el archivo funciones.cpp!" << endl;
}

// Definici�n de la funci�n sumar
int sumar(int a, int b) {
    return a + b;
}
